<?php

include "conection.php";

$sql = "SELECT * FROM inscreer ORDER BY id DESC";
$result = mysqli_query($con, $sql);


