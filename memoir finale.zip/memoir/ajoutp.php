<?php
 
 if (isset($_POST['ajouter'])) {
 	include "conection.php";
 	function validate($data){
 		$data = trim($data);
 		$data = stripslashes($data);
 		$data = htmlspecialchars($data);
 		return $data;

 	}

 	$nom = validate($_POST['Nom']);
 	$Prenom = validate($_POST['Prenom']);
 	$Telephone = validate($_POST['Telephone']);
 	$Chambre= validate($_POST['Chambre']);
 	$Codehabitant = validate($_POST['Code_habitant']);
 	$probleme = validate($_POST['probleme']);
	 $pavillon = validate($_POST['pavillon']);

	

 

 	
 		
 		$sql = "INSERT INTO inscreer(nom, prenom,  telephone, Chambre ,code_habitant, probleme,pavillon) 
 		        VALUES('$nom', '$Prenom',  '$Telephone', '$Chambre', '$Codehabitant', '$probleme','$pavillon')";
 		$result = mysqli_query($con, $sql);
 		if ($result) {
 		header("location: inscreer.php");
 		 }     
 	
 }



?>