<?php

session_start();


if( @$_GET["logout"] == 1 ){
  // kill session
  session_destroy();
  unset($_SESSION["id"]);
  header("location: chef%20pavillon.php");
  $_SESSION["id"] = "admin";
  exit;
}




if(  $_POST["adresse_email"] != "admin@admin.com" || $_POST["mot_de_passe"] != "admin123" )
{
  header("location: chef%20pavillon.php");
  exit;
}

$_POST =[];

$_SESSION["id"] = "admin";

?>



<?php include "voir.php"; ?>
<!DOCTYPE html>
<html>
<head>
	<title>liste reparation</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="css/style.css">
  
  
</head>
<body>

	
  <div class="container">
      <div class="box">
          <h4 class="display-4 text-center">Liste reparation</h4><hr><br>
          <?php if (isset($_GET['success'])) { ?>
     <div class="alert alert-success" role="alert">
      <?php echo $_GET['success']; ?>
      </div>
      <?php } ?>
      <?php if (mysqli_num_rows($result)) { ?>
          <table class="table table-striped">
            <thead>
              <tr>
              <th scope="col">id</th>
              <th scope="col">nom</th>
                <th scope="col">prenom</th>
                <th scope="col">telephone</th>
                <th scope="col">chambre</th>
                <th scope="col">code_habitant</th>
                <th scope="col">probleme</th>
                <th scope="col">pavillon</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $i = 1;
              while($rows = mysqli_fetch_assoc($result)){
                $i++;
                ?>
              <tr>
                
                <td><?=$rows['id']?></td>
                <td><?=$rows['nom']?></td>
                <td><?php echo $rows['prenom']; ?></td> 
                <td><?php echo $rows['telephone']; ?></td> 
                <td><?php echo $rows['chambre']; ?></td> 
                <td><?php echo $rows['code_habitant']; ?></td> 
                <td><?php echo $rows['probleme']; ?></td> 
                <td><?php echo $rows['pavillon']; ?></td> 

                <td>                    <a href="supprimer.php?idd=<?=$rows['id']?>" 
                
                       class="voir1.php">Supprimer</a></td> 

                       

 

                </td>   
               
                 
              </tr>
               <?php }  } ?>
            </tbody>
          </table>
          <a href="?logout=1"  class="btn btn-danger">deconexion</a>
      </div>
  </div>
</body>
</html>