
<?php  
   session_start();
    include("conection.php");
  

    

   

?>


<!DOCTYPE html>
<html dir="rtl" lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta property="og:title" content="طلبك" />
   
    <meta property="og:image" content="https://i.ibb.co/tMDGsYd/og.jpg"/>

    <link rel="stylesheet" href="style.css" />
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <title>طلبك</title>
  </head>
  <body>
    <div class="container">
      <div class="nav-container">
        <nav>
          <h3 class="logo">طلبك</h3>
          <ul>
            <li><a href="memoir.html">الصفحة الرئيسية</a></li>
          
          </ul>
        </nav>
      </div>
      <div class="hero">
        <div class="content">
         
          <h4>
           لقد تم تسجيل طلب خدمتك بنجاح
          </h4>
          
        </div>
      </div>
      
     
      <div id='aboutus' class="about-container">
        <section class="about-us">
            <div class="about-content">
              <h2>من نحن؟</h2>
              <p>
                شركة طلبك هي شركة توصيل تأسست في عام 2022 بهدف توفير السبل لكافة
                القطاعات لتوصيل منتجاتها لجميع الأرجاء. لدينا فروع منتشرة في كافة
                أنحاء المملكة. طاقمنا يتكون من مجموعة متنوعة من ذوي الخبرة في
                التوصيل والتعامل مع العملاء
              </p>
            </div>
            <img src="./images/who-are-we.jpg" alt="" />
        </div>
          </section>
      </div>
      
      <footer>
          <p>المعلومات أعلاه خياليه ولا تمثل أي شركة حقيقية. 2022 </p>
      </footer>
    </div>
  </body>
</html>
