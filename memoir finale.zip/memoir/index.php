


<!DOCTYPE html>
<html dir="rtl" lang="en">
  <head>
    <meta charset="UTF-8" />

    <link rel="stylesheet" href="style.css" />
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <title>طلبك</title>
  </head>
  <body>
    <div class="container">
      <div class="nav-container">
        <nav>
          <h3 class="logo">طلبك</h3>
          <ul>
            <li><a href="memoir.html">الصفحة الرئيسية</a></li>
            <li><a href="#aboutus">من نحن</a></li>
            <li><a href="#contactus">تواصل معنا</a></li>
          </ul>
        </nav>
      </div>
      <div class="hero">
        <div class="content">
          <h1>بدك <span> طلبك</span> يوصل بسرعة؟</h1>
          <h4>
            طلبك شركة بتقدملك أفضل وأسرع الحلول لتوصيل منتجاتك في كافة أنحاء
            المملكة
          </h4>
          <a href="#qualities" class="btn">إعرف أكثر عنا</a>
        </div>
      </div>
      
      <section id="qualities">
        <h2>ماذا نقدم لكم؟</h2>
        <div class="qualities-container">

        <div class="quality">
          <div class="header-container">
            <i class="fas fa-tachometer-alt"></i>
            <h3>سرعة كبيرة</h3>
          </div>
          <p>
            طلبك رح يوصل بمدة لا تتجاوز ثلاثة أيام عمل لكافة أنحاء المملكة لكثرة
            سيارات التوصيل المتوزعة في كافة المناطق
          </p>
        </div>
        <div class="quality">
          <div class="header-container">
            <i class="fas fa-star"></i>
            <h3>جودة عالية</h3>
          </div>
          <p>
            فريق مختص بخبرة كبيرة في التغليف والتوصيل لضمان وصول طلبك بدون أي
            أضرار وبشكل كامل وبكفاءة عالية
          </p>
        </div>
        <div class="quality">
          <div class="header-container">
            <i class="fas fa-money-bill-wave-alt"></i>
            <h3>أسعار رمزية</h3>
          </div>
          <p>
            نقدم لكم أفضل الأسعار المنافسة لكافة الشركات في كافة انحاء المملكة،
            بالإضافة إلى خصومات على التوصيل للكميات الكبيرة
          </p>
        </div>
      </section>
      <div id='aboutus' class="about-container">
        <section class="about-us">
            <div class="about-content">
              <h2>من نحن؟</h2>
              <p>
                شركة طلبك هي شركة توصيل تأسست في عام 2022 بهدف توفير السبل لكافة
                القطاعات لتوصيل منتجاتها لجميع الأرجاء. لدينا فروع منتشرة في كافة
                أنحاء المملكة. طاقمنا يتكون من مجموعة متنوعة من ذوي الخبرة في
                التوصيل والتعامل مع العملاء
              </p>
            </div>
            <img src="./images/who-are-we.jpg" alt="" />
        </div>
          </section>
      </div>
      <section id="contactus" class="contact-us">
        <h2>تواصل معنا</h2>
        <form>
          <label for="name">اسمك</label>
          <input type="text" id="name" name="name" />
          <label for="email">بريدك الالكتروني</label>
          <input type="email" id="email" name="email"/>
          <label for="msg">رسالتك لنا</label>
          <textarea name="message" id="msg" cols="30" rows="5"></textarea>
        <button class="btn" type='submit'>إرسال</button>
        </form>
      </section>
      <footer>
          <p>المعلومات أعلاه خياليه ولا تمثل أي شركة حقيقية. 2022 </p>
      </footer>
    </div>
  </body>
</html>
