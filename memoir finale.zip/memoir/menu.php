<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="animation.css">
</head>
<body>
 
    <header class="interface">
        
       
        <h1>Reparation</h1>
        <ul class="list">
            <li class="mini-list"><a class="main-link" href="">MENU</a></li>
            <li class="mini-list">
                <ul class="sub-ul">
                    <li><a href="habitant.php#">habitant</a></li>
                    <li><a href="chef%20pavillon.php#">l'hébergement</a></li>
                    
                </ul>
                <a class="main-link" href="#">INSCRUPTION</a></li>
            
            
            <li class="mini-list"><a class="main-link" href="index.php#">COMPAGNE de travaille </a></li>
        </ul>
       
    </header>
    
    <main>Site web pour les habitants à joindre les travailleurs de l'hébergement par les chef pavillons,pour déterminer le meilleur temps pour faire des réparations</main>
    <footer><a href="https://elearning-facsc.univ-annaba.dz/">elearning-facsc.univ-annaba.dz</a>
        <span>
            &#128293
        </span>
    </footer>

    
</body>
</html>








