<?php
                        session_start();
                        include("conection.php");
    


                        if($_SERVER['REQUEST_METHOD'] == "POST")
                        {
   	                    //something was posted
   	                    $adresse_email = $_POST['adresse_email'];
   	                    $mot_de_passe = $_POST['mot_de_passe'];

   	                    if(!empty($adresse_email) && !empty($mot_de_passe) && !is_numeric($adresse_email))
   	                    {
   		                //read from data base
   		                $query = "SELECT * FROM users WHERE adresse_email = '$adresse_email' LIMIT 1";

   		                $result = mysqli_query($con, $query);

   		                if($result)
   		                {
   			            if($result && mysqli_num_rows($result) > 0)
   			             {
		

			            $user_data = mysqli_fetch_assoc($result);
			            if($user_data['mot de passe'] === $mot_de_passe)
			                {
				        $_SESSION['adresse_email'] = $user_data['adresse_email'];
				        header("location: voir1.php");
   		                die;
			                }
		                 }
   		                }

   		                echo "entrer une information valide";
       
   	                    }else
   	                    {
   		                echo "entrer une information valide";
   	                    }
                        } 

                        ?>  


<!DOCTYPE html>
<html>
<head>
	<title>Login</title>

</head>
<body>
	<style type="text/css">
		*{
	
	
    margin: 0;
    padding: 0;
    font-family: sans-serif;
}
.hero{
	height: 100%;
	width: 100%;
	background-image: linear-gradient(rgba(0,0,0,0.2),rgba(0,0,0,0.4)),url(img1.jpg);
	background-position: center;
	background-size: cover;
	position: absolute;
}


.form-box{
	width: 380px;
	height: 480px;
	position: relative;
	margin: 6% auto;
	background: #fff;
	padding: 5px;
	overflow: hidden;
	border-radius: 30px;
}
.button-box{
	width: 220px;
	margin: 35px auto;
	position: relative;
	box-shadow: 0 0 20px 9px #ff61241f;
	border-radius: 30px;

}
.toggel-btn{
	padding: 20px 160px;
	cursor: pointer;
	background: transparent;
	border: 0;
	outline: none;
	position: relative;
	text-decoration: underline;
}
#btn{
	top: 0;
	left: 0;
	position: absolute;
	width: 110px;
	height: 100%;
	background: linear-gradient(to right, #0F8FE3,#0F8FE3);

	border-radius: 30px;
	transition: .5s;

}
.input-groupe{
	top: 180px;
	position: absolute;
	width: 280px;
	transition: .5s
}
.input-field{
	width: 100%;
	padding: 10px 0;
	margin: 5px 0;
	border-left: 0;
	border-top: 0;
	border-right: 0;
	border-bottom: 1px solid #999;
	outline: none;
	background: transparent;
}
.submit-btn{
	width: 85%;
	padding: 10px 30px;
	cursor: pointer;
	display: block;
	margin: auto;
	background: linear-gradient(to right, #0F8FE3,#0F8FE3);
	border: 0;
	outline: none;
	border-radius: 30px;
	text-decoration: none;
}
a{
	text-decoration: none;
}
.chech-box{
	margin: 30px 10px 30px 0;

}
span{
	color: #777;
	font-size: 12px;
	bottom: 195px;
	position: absolute;
}
#loginn{
	left: 50px;
}
#register{
	left: 450px;
}
h2{
	padding: 10px 37px;
}

		
	</style>
 <form method="post">
	<div class="hero">
		<div class="form-box">
			<div class="button-box">
				          <h2>Connexion</h2>
						
                    
				
               

				
			</div>
			<form id="loginn" class="input-groupe">
				<input type="email" name="adresse_email" class="input-field" placeholder="Adresse email" required><br><br>
				<input type="password" name="mot_de_passe" class="input-field" placeholder="Mot de passe" required><br><br>
                <input type="checkbox" class="chech-box"><span>autoriser l`acces</span>
                <a href="voir1.php"><button type="submit-btn" class="submit-btn" style="color: #fff">connecter</button></a>
			    
		</form>
		
		</form>

			
			
		</div>

		
	</div>

	<script>
       
       var x=document.getElementById("login");	
       var y=document.getElementById("register");
        var z=document.getElementById("btn");	
        function register(){
        	x.style.left = "-400px";
        	y.style.left = "50px";
        	z.style.left = "110px";
        }	
         function loginn(){
        	x.style.left = "50px";
        	y.style.left = "450px";
        	z.style.left = "0";
        }	



	</script>
		
	

</body>
</html>

<!--<button type="button" class="toggel-btn" onclick="loginn()">Se connecter</button>
<div id="btn"></div>
				