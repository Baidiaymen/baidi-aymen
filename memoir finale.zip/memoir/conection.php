<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "memoir";

if(!$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname))
{
	die("failed to connect");
}