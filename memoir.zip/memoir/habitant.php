


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document1</title>
    <link rel="stylesheet" href="2.css">
    
    <link rel="stylesheet" href="animation.css">

</head>
<body>
    <form action="ajoutp.php" 
		      method="post">>
        
        



            <header class="interface">
                <h1>Reparation</h1>
                <ul class="list">
                    <li class="mini-list"><a class="main-link" href="menu.php">MENU</a></li>
                    <li class="mini-list">
                        <ul class="sub-ul">
                            <li><a href="habitant.php">habitant</a></li>
                            <li><a href="chef%20pavillon.php#">l'hébergement</a></li>
                        </ul>
                        <a class="main-link" href="#">INSCRUPTION</a></li>
                    
                    
                    <li class="mini-list"><a class="main-link" href="index.php#">COMPAGNE de travaille </a></li>
                </ul>
    
            </header>
            <main>   
                 <div class="A">
                     <h2>Demande de Réglage
                     </h2>
                    <input type="text" placeholder="Nom..." name="Nom"required>
                    <br>
                    <input type="text" placeholder="Prenom..."name="Prenom"required>
                    <br>
                    
                    <input type="number" placeholder="Telephone..."name="Telephone"required>
                    <br>
                    
                    
                    
                    
                    
                    <input type="number" placeholder="Chambre..."name="Chambre"required>
                    <br>
                    
                    <input type="number" placeholder="Code habitant... "name="Code habitant"required>
                    <br>
                    <label>probleme </label>
                    <select class="B" name="probleme" >
                    <option >verre de fenètre</option>
                        <option >la fenètre</option>
                        <option >la porte</option>
                        <option >la serrure</option>
                        <option >lit/table/chaise</option>
                        <option >les lamps/les prise</option>
                         
                    </select>
                    <br>
                    <label>Pavillon  </label>
                    <select class="B" name="pavillon">
                    
                    <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>

                    </select>
                    
                        <br>
                    <button name="ajouter"> 
                    
                    Valider
                    </button>
                    
                


                 </div>
                       
            </main>
            <footer><a href="https://elearning-facsc.univ-annaba.dz/">elearning-facsc.univ-annaba.dz</a>
                <span> 
                    &#128294;
                    &#128295;
                    &#128296;
                    &#128297;
                    
                </span>
            </footer>
        
    
    </form>
</body>
</html>