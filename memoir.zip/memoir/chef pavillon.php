
<!DOCTYPE html>





<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document2</title>
    <link rel="stylesheet" href="stale2.css">
    <link rel="stylesheet" href="animation.css">
</head>
<body>
            <header class="interface">
                <h1>Reparation</h1>
                <ul class="list">
                    <li class="mini-list"><a class="main-link" href="menu.php">MENU</a></li>
                    <li class="mini-list">
                        <ul class="sub-ul">
                            
                            <li><a href="habitant.php#">habitant</a></li>
                            <li><a href="chef%20pavillon.php">l'hébergement</a></li>
                        </ul>
                        <a class="main-link" href="#">INSCRUPTION</a></li>
                    
                    
                    <li class="mini-list"><a class="main-link" href="index.php#">COMPAGNE de travaille </a></li>
                </ul>
        
            </header>
            <main>   
                 <div class="A">
                     <h2>Admini
                     </h2>

                    
                    
        
                     <form action="voir1.php" method="post">
                        <input  type="email" name="adresse_email" class="input-field" placeholder="Adresse email" required><br>
                        <input type="password" name="mot_de_passe" class="input-field" placeholder="Mot de passe" required><br>
                        <input type="submit" class="submit-btn" style="color: #fff" value="connecter" >
                   
                    </form>

                 </div>
                       
            </main>
           
    <footer><a href="https://elearning-facsc.univ-annaba.dz/">elearning-facsc.univ-annaba.dz</a>
        <span>
            &#9937
            &#128736
        </span>
    </footer>
        
    
   
   
</body>
</html>