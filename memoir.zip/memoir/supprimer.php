<?php

if (isset($_GET['id'])) {
      include "connection.php";
	    function validate($data){
 		    $data = trim($data);
 		    $data = stripslashes($data);
 		    $data = htmlspecialchars($data);
 		    return $data;

 	}

 	$id = validate($_GET['id']);

 	$sql = "DELETE FROM inscreer
 	        WHERE 'id'=$id";
 		$result = mysqli_query($con, $sql);
 		if ($result) {
 		header("location: voir1.php?success=supprimer avec succes");
 		 }else {
 		 	header("location: voir1.php?error=unknown error occured&user_data");



			  
 		 }        

}else{
	header("location: voir1.php");
}
